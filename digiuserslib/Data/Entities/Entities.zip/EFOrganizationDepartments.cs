﻿namespace digiuserslib.Data.Entities;

public class EFOrganizationDepartments {
  public string OrganizationId { get; set; } = string.Empty;
  public EFOrganization Organization { get; set; } = null!;

  public string DepartmentId { get; set; } = string.Empty;
  public EFDepartment Department { get; set; } = null!;
}

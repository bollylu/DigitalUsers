﻿using System;
using System.Collections.Generic;
using System.Text;

namespace digiuserslib.Data.Entities;

public class EFOrganizationContacts {
  public string ContactId { get; set; } = string.Empty;
  public EFContact Contact { get; set; } = null!;

  public string OrganizationId { get; set; } = string.Empty;
  public EFOrganization Organization { get; set; } = null!;
}
